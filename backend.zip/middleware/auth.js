import admin from '../config/firebase.js';

export const verifyToken = async (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Unauthorized: No token provided' });
    }

    const token = authHeader.split(' ')[1];

    try {
        const decodedToken = await admin.auth().verifyIdToken(token);
        req.user = decodedToken;
        next();
    } catch (error) {
        console.error('Error verifying Firebase token:', error.message);
        res.status(401).json({ error: 'Unauthorized: Invalid token' });
    }
};

export const isAdmin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        // Fallback check if role isn't in custom claims yet
        // You might want to check a list of admin emails or a DB table
        if (req.user && (req.user.email === 'admin@jadetimes.com' || req.user.admin === true)) {
            next();
        } else {
            res.status(403).json({ error: 'Forbidden: Admin access required' });
        }
    }
};
